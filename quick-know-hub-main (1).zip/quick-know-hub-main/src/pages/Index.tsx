import Landing from './Landing';

export default function Index() {
  return <Landing />;
}